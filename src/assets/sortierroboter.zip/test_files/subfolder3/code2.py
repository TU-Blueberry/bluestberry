Hier ist toller Python Code!
