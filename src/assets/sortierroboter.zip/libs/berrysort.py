import os
import random

import js
import numpy as np
from skimage import io
from sklearn import metrics

path = "sortierroboter/BlueberryData/"


class TestDataLoader:
    _loaded_test_data = None

    def _load_images(self):
        loaded_test_data = []
        for file in os.listdir(path + "TestData/"):
            res = io.imread(path + "TestData/" + file)
            if 'good' in file:
                label = 1
            elif 'bad' in file:
                label = 0
            else:
                # image with incorrect name format
                continue
            loaded_test_data.append((res, label, path + "TestData/" + file))
            random.shuffle(loaded_test_data)
        self._loaded_test_data = loaded_test_data

    def evaluate_metric(self, predict_func, metric=metrics.accuracy_score, **kwargs):
        if self._loaded_test_data is None:
            self._load_images()
        test_images = [entry[0] for entry in self._loaded_test_data]
        y_pred = predict_func(test_images)
        labels = np.array([entry[1] for entry in self._loaded_test_data])
        return metric(y_pred=y_pred, y_true=labels, **kwargs)

    def send_to_unity(self, predict_func):
        if self._loaded_test_data is None:
            self._load_images()
        test_images = [entry[0] for entry in self._loaded_test_data]
        y_pred = predict_func(test_images)

        js.enableManual()
        for i in range(len(self._loaded_test_data)):
            arg = "{},{},{}".format(self._loaded_test_data[i][1], y_pred[i], self._loaded_test_data[i][2])
            js.sendManualBerry(arg)
