Hier wohnt der Code von Lektion 2.
